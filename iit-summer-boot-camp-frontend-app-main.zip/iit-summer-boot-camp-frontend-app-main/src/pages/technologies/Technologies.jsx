const Technologies = () => {
  return (
    <div>
      <h1 className="title">Technologies</h1>
      <p className="content">
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Magnam
        reiciendis nam hic nobis, exercitationem quibusdam, eligendi assumenda
        animi libero commodi quae excepturi eveniet rerum! Quod commodi culpa
        quo rerum cupiditate.
      </p>
    </div>
  );
};

export default Technologies;
